let imagen;
let meuSom;

function preload() {
  imagem = loadImage('waguinimg.jpg');//https://pt.wikipedia.org/wiki/Ficheiro:Floresta_da_Tijuca_52.jpg
  
  
  


  meuSom = loadSound("waguin,som.mp3");//https://pixabay.com/pt/sound-effects/forest-ambience-296528/


}

function setup() {
  createCanvas (1500,1500);

 
  background(220);
 
  meuSom.setVolume(0.5); // Define o volume para metade
  meuSom.play(); // Reproduz o som carregado

}

function draw() {
  background('white');
  image(imagem,0,0);
  textFont('Courier New')
  textSize(24)
  fill('#09FD1D');
  text("Sou uma alma cheia de florestas e mares!!!",300,650)
  
}

function mousePressed() {
  meuSom.stop(); // Interrompe a reprodução ao pressionar o mouse
}